<?php $__env->startSection('content'); ?>
  <div class="row">
    <?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <strong>Success! </strong><?php echo e(session()->get('message')); ?>

    </div>
    <?php endif; ?>
      <div class="col-lg-12">
          <h1 class="page-header">Manage Projects</h1>
      </div>
      <!-- /.col-lg-12 -->
  </div>
  <div class="row">


      <br>
      <div class="col-lg-12">

          <!-- Project edit or delete-->
          <div class="panel panel-primary">
              <div class="panel-heading">
                  Manage project here
              </div>

              <div class="panel-body">
                <!--Table of project-->
                  <table class="table table-striped">
                    <thead>
                      <tr>
                        <th>Id</th>
                        <th>Title</th>
                        <th>Post created</th>
                        <th>Last Updated</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                      <tr>
                        <td><?php echo e($project->id); ?></td>
                        <td><?php if(strlen($project->title) > 50): ?>
                          <?php echo e(substr($project->title, 0, 50)); ?>

                        <?php else: ?>
                          <?php echo e($project->title); ?>

                        <?php endif; ?></td>
                        <td><?php echo e($project->created_at); ?></td>
                        <td><?php echo e($project->updated_at); ?></td>
                        <td class="pull-right">
                          <a href="/radhasarisha/editProject/<?php echo e($project->id); ?>"><button type="button" class="btn btn-warning">Edit</button></a>
                          <a href="/project/delete/<?php echo e($project->id); ?>"><button type="button" class="btn btn-danger">Delete</button></a>

                        </td>
                      </tr>

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                  </table>
                <!--End of Table-->
          </div>

      </div>
      <!-- /.col-lg-4 -->
  </div>
  <!-- /.row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.masterAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
  <div class="row">
    <?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <strong>Success! </strong><?php echo e(session()->get('message')); ?>

    </div>
    <?php endif; ?>
      <div class="col-lg-12">
          <h1 class="page-header">Messages</h1>
      </div>
      <!-- /.col-lg-12 -->
  </div>
  <div class="row">


      <br>
      <div class="col-lg-12">

          <!-- Project edit or delete-->
          <div class="panel panel-primary">
              <div class="panel-heading">
                  Messages from user
              </div>

              <div class="panel-body">
                <!--Table of project-->
                  <table class="table table-striped">
                    <thead>
                      <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Messages</th>
                        <th>Time</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                      <tr>
                        <td><?php echo e($message->id); ?></td>
                        <td><?php echo e($message->name); ?></td>
                        <td><?php echo e($message->email); ?></td>
                        <td><?php echo e($message->messages); ?></td>


                        <td class="pull-right">
                          
                          <?php echo e($message->created_at); ?>

                        </td>
                      </tr>

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                  </table>
                <!--End of Table-->
          </div>

      </div>
      <!-- /.col-lg-4 -->
  </div>
  <!-- /.row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.masterAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
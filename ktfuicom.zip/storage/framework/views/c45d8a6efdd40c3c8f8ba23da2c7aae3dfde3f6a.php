<!--Bagian sini banyak yg belum-->



<?php $__env->startSection('content'); ?>
<br><br><br>
<?php if(session()->has('message')): ?>
<div class="alert alert-success">
    <strong>Success! </strong><?php echo e(session()->get('message')); ?>

</div>
<?php endif; ?>

<?php if(count($errors) > 0): ?>
  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-danger">
        <strong>Failed!</strong> <?php echo e($error); ?>

    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<div class="w3-row">
	<!-- Header -->
  <header id="portfolio">
    <div class="w3-container">
    <h1><b>Project</b></h1>
    <div class="w3-section w3-bottombar w3-padding-16">
      <span class="w3-margin-right">Filter:</span>
      <button class="w3-button w3-orange">ALL</button>
      <button class="w3-button w3-white"><i class="fa fa-diamond w3-margin-right"></i>Misi Budaya</button>
      <button class="w3-button w3-white"><i class="fa fa-photo w3-margin-right"></i>Pagelaran</button>
      <button class="w3-button w3-white"><i class="fa fa-map-pin w3-margin-right"></i>Lomba Besar</button>
    </div>
    </div>
  </header>

  <!-- First Photo Grid-->
  <div class="w3-row-padding">
    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="w3-third w3-container w3-margin-bottom">
  	    <a href="/projects/<?php echo e($project->id); ?>"><img src="<?php echo e(asset('storage/project_img/' . $project->id . '/1.png')); ?>" alt="Norway" width="425.33" height="281.77" class="w3-hover-opacity"></a>
        <div class="w3-container w3-white">
          <p><b><?php if(strlen($project->title) > 50): ?>
            <?php echo e(substr($project->title, 0, 50)); ?>

          <?php else: ?>
            <?php echo e($project->title); ?>

          <?php endif; ?></b></p>
          <p><?php echo e($project->content); ?></p>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
  </div>

  <!-- Pagination -->
  <div class="w3-center w3-padding-32">
    <div class="w3-bar">
      <a href="#" class="w3-bar-item w3-button w3-hover-orange">«</a>
      <a href="#" class="w3-bar-item w3-orange w3-button">1</a>
      <a href="#" class="w3-bar-item w3-button w3-hover-orange">2</a>
      <a href="#" class="w3-bar-item w3-button w3-hover-orange">3</a>
      <a href="#" class="w3-bar-item w3-button w3-hover-orange">4</a>
      <a href="#" class="w3-bar-item w3-button w3-hover-orange">»</a>
    </div>
  </div>

<!-- End Page Content -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
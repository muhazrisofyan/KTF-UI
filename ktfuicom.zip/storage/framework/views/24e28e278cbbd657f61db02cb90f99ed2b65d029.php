<?php $__env->startSection('content'); ?>
  <div class="row">
    <?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <strong>Success! </strong><?php echo e(session()->get('message')); ?>

    </div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">
            <strong>Failed!</strong> <?php echo e($error); ?>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
      <div class="col-lg-12">
          <h1 class="page-header">Contact Person</h1>
      </div>
      <!-- /.col-lg-12 -->
  </div>
  <div class="row">


      <br>
      <div class="col-lg-12">
          <div class="panel panel-primary">
              <div class="panel-heading">
                  Edit contact person
              </div>

              <form action="/contactupdate" method="post">
                  <div class="panel-body">

                      <div class="form-group">
                          <label>Name</label>
                          <input type="text" class="form-control" name="name" value="<?php echo e($nama); ?>" id="name">
                      </div>

                      <div class="form-group">
                          <label>Phone number</label>
                          <input type="text" class="form-control" name="hp" value="<?php echo e($phonenumber); ?>" id="hp">
                      </div>

                      <div class="form-group">
                          <label>Email</label>
                          <input type="text" class="form-control" name="email" value="<?php echo e($email); ?>" id="email">
                      </div>

                  </div>

                  <div class="panel-footer">
                      <button class="btn btn-primary" type="submit" name="save" value="Save">Save</button>
                      <?php echo e(csrf_field()); ?>

                  </div>
              </form>
          </div>
      </div>
      <!-- /.col-lg-4 -->
  </div>
  <!-- /.row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.masterAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
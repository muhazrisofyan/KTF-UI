<?php $__env->startSection('content'); ?>
  <div class="row">
      <div class="col-lg-12">
          <h1 class="page-header">Dashboard</h1>
      </div>
      <!-- /.col-lg-12 -->
  </div>
  <!-- /.row -->
  
    <h1>Welcome, Admin!</h1>
    <a href="<?php echo e(route('logout')); ?>"
        onclick="event.preventDefault();
                 document.getElementById('logout-form').submit();"><i class="fa fa-sign-out fa-fw"></i> Logout</a>             
  <!-- /.row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.masterAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
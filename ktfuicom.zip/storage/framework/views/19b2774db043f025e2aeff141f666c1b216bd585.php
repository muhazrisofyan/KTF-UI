<?php $__env->startSection('content'); ?>

  <?php if(session()->has('message')): ?>
  <div class="w3-panel w3-green">
    <strong>Success! </strong><?php echo e(session()->get('message')); ?>

  </div>
  <?php endif; ?>



<div class="w3-center" style="padding-top:150px;padding-bottom:60px">
  <img src="img/Logo KTF.PNG" alt="logo" style="max-width:500px;width:100%">
</div>

<div class="w3-row w3-container">
  <div class="w3-orange w3-text-white w3-container w3-third" style="padding-bottom:400px;margin-bottom:100px;padding-top:50px;">
    <h2>Get Social</h2>
    <div class="w3-row">
      <div class="w3-container w3-xlarge w3-center">
        <a target="_blank" href="https://www.instagram.com/ktfui/"><i class="fa fa-instagram w3-hover-opacity contactimage"></i></a>
        <a target="_blank" href="https://www.youtube.com/user/KTFfisipUI08"><i class="fa fa-youtube w3-hover-opacity contactimage"></i></a>
        <span class="w3-mobile">
        <a target="_blank" href="hhttps://twitter.com/ktfui"><i class="fa fa-twitter w3-hover-opacity contactimage"></i></a>
        <a target="_blank" href="https://www.facebook.com/ktf.ui.radhasarisha"><i class="fa fa-facebook-official w3-hover-opacity contactimage"></i></a>
        </span>
      </div>
    </div>
    <h2 style="padding-top:60px">Contact Info</h2>
    <span class="contactinfo"><i class="fa fa-phone" style="margin-left:80px;margin-top:0px;padding-top:25px">  <?php echo e($nama); ?> (<?php echo e($phonenumber); ?>)</i></span>
    <br>
    <span class="contactinfo"><i class="fa fa-envelope" style="margin-left:80px">  <?php echo e($email); ?></i></span>
  </div>
  <div class="w3-container w3-twothird w3-light-grey w3-display-container" style="padding-bottom:324px;margin-bottom:100px;padding-top:50px;">
    <h2 class="w3-text-orange"style="padding-bottom:25px">Get in touch with us</h2>
    <?php if(count($errors) > 0): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="w3-panel w3-red">
          <strong>Failed!</strong> <?php echo e($error); ?>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <form action="/sendMessage" method="post">
      <label>Your Name (Required)</label>
      <input class="w3-input w3-border-0 w3-round-large" type="text" style="margin-top:10px;" name="name">
      <br>
      <label>Your Email (Required)</label>
      <input class="w3-input w3-border-0 w3-round-large" type="text" style="margin-top:10px;" name="email">
      <br>
      <label>Your Message </label>
      <textarea class="w3-input w3-border-0 w3-round-large" type="text" rows="5" style="margin-top:10px;" name="message"></textarea>
      <button class="w3-btn w3-orange w3-text-white w3-display-bottomright" style="margin-right:50px;margin-bottom:50px">Submit</button>
      <?php echo e(csrf_field()); ?>

    </form>
  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
  <div class="row">
    <?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <strong>Success! </strong><?php echo e(session()->get('message')); ?>

    </div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">
            <strong>Failed!</strong> <?php echo e($error); ?>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
      <div class="col-lg-12">
          <h1 class="page-header">Edit Project</h1>
      </div>

      <!-- /.col-lg-12 -->
  </div>
  <div class="row">
      <br>
      <div class="col-lg-12">
          <div class="panel panel-primary">
              <div class="panel-heading">
                  Edit your project
              </div>



                <form action="/project/edit/<?php echo e($project->id); ?>" method="post" enctype="multipart/form-data">
                  <div class="panel-body">
                    <div class="form-group">
                      <label for="title">Title</label>
                      <input type="text" class="form-control" id="title" name="title" value="<?php echo e($project->title); ?>">
                    </div>

                    <div class="form-group">
                      <label for="content">Content</label>
                      <textarea class="form-control" rows="5" id="content" name="content"><?php echo e($project->content); ?></textarea>
                    </div>

                    <div class="form-group">
                      <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset('storage/project_img/' . $project->id . '/' . $image)); ?>" alt="Norway" width="100" height="100">
                        <br><a href="/project/deleteImage/<?php echo e($project->id); ?>/<?php echo e($image); ?>"><button type="button" class="btn btn-danger">Delete</button></a>
                        <br>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <br>
                      <label for="comment">Add Images (can attach more than one):</label>
                      <input type="file" id="pictures" name="photos[]" multiple/ >
                    </div>

                  </div>

                  <div class="panel-footer">
                    <button type="submit" class="btn btn-primary">Save</button>
                      <?php echo e(csrf_field()); ?>

                  </div>
                </form>



          </div>
      </div>
      <!-- /.col-lg-4 -->
  </div>
  <!-- /.row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.masterAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>